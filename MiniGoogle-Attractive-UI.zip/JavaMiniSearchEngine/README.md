# Mini Google - Live Web Search (Java 17+)

A Java Swing educational search engine designed to feel like a small Google-style search page.

## What it does
- Search the live web from one search box.
- Shows real result titles, URLs and snippets.
- Click a result to open the real website in the default browser.
- Uses Java HttpClient for networking.
- Uses Swing + SwingWorker so the UI remains responsive.
- Uses a Trie to store discovered title terms for future autocomplete expansion.
- Keeps the earlier crawler/indexing/ranking classes in the project for demonstrating core Java concepts and future offline indexing.

## Important
This is not Google's own index. For an educational project, the program sends the query to a public HTML search endpoint and presents the returned web results. Internet access is required.

## Java version
Java 17 or newer.

## Compile with CMD
From the `JavaMiniSearchEngine` folder:

```cmd
javac -d out -encoding UTF-8 src\model\*.java src\indexing\*.java src\ranking\*.java src\search\*.java src\datastructures\*.java src\crawler\*.java src\database\*.java src\Main.java
java -cp out Main
```

## Try searches
- java tutorial
- best java projects
- machine learning
- latest technology
- data structures

## Main Java concepts demonstrated
OOP, classes/objects, encapsulation, collections, HashMap/Set, PriorityQueue, Trie, multithreading, ExecutorService, HttpClient, URI/URL encoding, file handling, serialization, Swing GUI, event handling, SwingWorker, exceptions, streams/lambdas, and ranking.
