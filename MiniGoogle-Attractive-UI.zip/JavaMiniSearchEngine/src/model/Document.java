package model;

import java.io.Serializable;

public class Document implements Serializable {
    private static final long serialVersionUID = 1L;
    private final int id;
    private final String title;
    private final String content;
    private final String path;
    private final String url;

    public Document(int id, String title, String content, String path) {
        this(id, title, content, path, path);
    }

    public Document(int id, String title, String content, String path, String url) {
        this.id = id;
        this.title = title == null || title.isBlank() ? "Untitled Page" : title;
        this.content = content == null ? "" : content;
        this.path = path == null ? "" : path;
        this.url = url == null || url.isBlank() ? this.path : url;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getPath() { return path; }
    public String getUrl() { return url; }
}
