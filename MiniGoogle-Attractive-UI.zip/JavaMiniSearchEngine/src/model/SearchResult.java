package model;
public class SearchResult { private final Document document; private final double score;
 public SearchResult(Document d,double s){document=d;score=s;} public Document getDocument(){return document;} public double getScore(){return score;} }
