package crawler;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.regex.*;

/** Small educational same-domain web crawler. */
public class WebCrawler {
    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8))
            .followRedirects(HttpClient.Redirect.NORMAL).build();
    private final int maxPages, maxDepth;
    private final Map<String,String> pageTitles = new LinkedHashMap<>();

    public WebCrawler(int maxPages, int maxDepth) { this.maxPages=maxPages; this.maxDepth=maxDepth; }
    public Map<String,String> getPageTitles(){ return pageTitles; }

    public int crawlToDirectory(String startUrl, Path output) throws Exception {
        Files.createDirectories(output);
        URI start = normalize(URI.create(startUrl), startUrl);
        String host = start.getHost();
        Queue<UrlDepth> queue = new ArrayDeque<>();
        Set<String> visited = new HashSet<>();
        queue.add(new UrlDepth(start.toString(),0));
        int count=0;
        while(!queue.isEmpty() && count<maxPages){
            UrlDepth item=queue.poll();
            if(item.depth>maxDepth || !visited.add(item.url)) continue;
            try{
                HttpRequest req=HttpRequest.newBuilder(URI.create(item.url)).timeout(Duration.ofSeconds(10))
                        .header("User-Agent","MiniGoogleBot/1.0 (Educational Project)").GET().build();
                HttpResponse<String> res=client.send(req,HttpResponse.BodyHandlers.ofString());
                String type=res.headers().firstValue("content-type").orElse("");
                if(res.statusCode()>=400 || !type.toLowerCase().contains("text/html")) continue;
                String html=res.body();
                String title=title(html); String text=text(html);
                if(text.length()<20) continue;
                count++;
                pageTitles.put(item.url,title);
                String file=String.format(Locale.ROOT,"web_%03d.txt",count);
                String content="TITLE: "+title+"\nURL: "+item.url+"\n\n"+text;
                Files.writeString(output.resolve(file),content,StandardCharsets.UTF_8);
                if(item.depth<maxDepth){
                    for(String raw: links(html)){
                        try{
                            URI u=normalize(URI.create(item.url),raw);
                            if(u!=null && Objects.equals(host,u.getHost()) && !visited.contains(u.toString()))
                                queue.add(new UrlDepth(u.toString(),item.depth+1));
                        }catch(Exception ignored){}
                    }
                }
            }catch(Exception ignored){}
        }
        return count;
    }

    private static URI normalize(URI base,String raw){
        URI u=base.resolve(raw);
        if(!"http".equalsIgnoreCase(u.getScheme()) && !"https".equalsIgnoreCase(u.getScheme())) return null;
        return URI.create(u.getScheme()+"://"+u.getAuthority()+
                (u.getPath()==null||u.getPath().isEmpty()?"/":u.getPath())+
                (u.getQuery()==null?"":"?"+u.getQuery()));
    }
    private static String title(String html){
        Matcher m=Pattern.compile("(?is)<title[^>]*>(.*?)</title>").matcher(html);
        return m.find()?clean(m.group(1)):"Untitled Page";
    }
    private static String text(String html){
        String s=html.replaceAll("(?is)<script.*?</script>"," ")
                .replaceAll("(?is)<style.*?</style>"," ")
                .replaceAll("(?is)<noscript.*?</noscript>"," ");
        s=s.replaceAll("(?is)<[^>]+>"," ");
        return clean(s);
    }
    private static Set<String> links(String html){
        Set<String> out=new LinkedHashSet<>();
        Matcher m=Pattern.compile("(?is)<a\\s+[^>]*href\\s*=\\s*[\\\"']([^\\\"'#]+)[\\\"'][^>]*>").matcher(html);
        while(m.find()) out.add(m.group(1).trim());
        return out;
    }
    private static String clean(String s){
        return s.replaceAll("(?s)&nbsp;"," ").replaceAll("(?s)&amp;","&")
                .replaceAll("(?s)&lt;","<").replaceAll("(?s)&gt;",">")
                .replaceAll("\\s+"," ").trim();
    }
    private record UrlDepth(String url,int depth){}
}
