import datastructures.Trie;
import search.WebResult;
import search.WebSearchClient;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.net.URI;
import java.util.List;
import java.util.concurrent.ExecutionException;

/** A polished Swing UI for the Mini Google educational search engine. */
public class Main {
    private static final Color BG = new Color(12, 17, 32);
    private static final Color PANEL = new Color(22, 29, 49);
    private static final Color PANEL_LIGHT = new Color(29, 38, 62);
    private static final Color TEXT = new Color(239, 243, 255);
    private static final Color MUTED = new Color(158, 171, 197);
    private static final Color ACCENT = new Color(139, 92, 246);
    private static final Color ACCENT_2 = new Color(56, 189, 248);
    private static final Color URL = new Color(74, 222, 128);
    private static final Font BODY = new Font("SansSerif", Font.PLAIN, 14);
    private static final Font SMALL = new Font("SansSerif", Font.PLAIN, 12);
    private static final Font TITLE = new Font("SansSerif", Font.BOLD, 17);

    private final WebSearchClient web = new WebSearchClient();
    private final Trie suggestions = new Trie();
    private JFrame frame;
    private JTextField searchBox;
    private JPanel results;
    private JLabel status;
    private JPanel content;
    private boolean resultsMode = false;

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) { }
        SwingUtilities.invokeLater(() -> new Main().showHome());
    }

    private void showHome() {
        resultsMode = false;
        results = null;
        frame = new JFrame("Mini Google — Explore the web");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(760, 620));
        frame.setSize(1080, 760);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(BG);

        JPanel root = new GradientPanel();
        root.setLayout(new BorderLayout());
        root.setBorder(new EmptyBorder(24, 34, 24, 34));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel brand = brandLabel(22);
        top.add(brand, BorderLayout.WEST);
        JLabel tag = new JLabel("JAVA • LIVE WEB SEARCH");
        tag.setFont(new Font("SansSerif", Font.BOLD, 10));
        tag.setForeground(new Color(186, 196, 220));
        top.add(tag, BorderLayout.EAST);
        root.add(top, BorderLayout.NORTH);

        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBorder(new EmptyBorder(95, 70, 50, 70));

        JLabel orb = new JLabel("✦");
        orb.setFont(new Font("SansSerif", Font.BOLD, 30));
        orb.setForeground(new Color(196, 181, 253));
        orb.setAlignmentX(Component.CENTER_ALIGNMENT);
        center.add(orb);
        center.add(Box.createVerticalStrut(12));

        JLabel headline = new JLabel("Find your next answer.");
        headline.setFont(new Font("SansSerif", Font.BOLD, 39));
        headline.setForeground(TEXT);
        headline.setAlignmentX(Component.CENTER_ALIGNMENT);
        center.add(headline);
        center.add(Box.createVerticalStrut(12));

        JLabel subtitle = new JLabel("A little search engine. A whole web of possibilities.");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 16));
        subtitle.setForeground(MUTED);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        center.add(subtitle);
        center.add(Box.createVerticalStrut(32));

        JPanel searchWrap = new RoundedPanel(PANEL, 24);
        searchWrap.setLayout(new BorderLayout(12, 0));
        searchWrap.setBorder(new EmptyBorder(9, 18, 9, 10));
        searchWrap.setMaximumSize(new Dimension(720, 62));
        searchWrap.setPreferredSize(new Dimension(650, 62));
        searchWrap.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel searchIcon = new JLabel("⌕");
        searchIcon.setFont(new Font("SansSerif", Font.PLAIN, 28));
        searchIcon.setForeground(MUTED);
        searchWrap.add(searchIcon, BorderLayout.WEST);
        searchBox = createSearchField("Search anything on the web...");
        searchWrap.add(searchBox, BorderLayout.CENTER);
        JButton search = accentButton("Search  ↗");
        searchWrap.add(search, BorderLayout.EAST);
        center.add(searchWrap);
        center.add(Box.createVerticalStrut(27));

        JLabel explore = new JLabel("TRY A SEARCH");
        explore.setFont(new Font("SansSerif", Font.BOLD, 10));
        explore.setForeground(MUTED);
        explore.setAlignmentX(Component.CENTER_ALIGNMENT);
        center.add(explore);
        center.add(Box.createVerticalStrut(12));
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        chips.setOpaque(false);
        for (String sample : new String[]{"Java tutorials", "AI technology", "Data structures", "Project ideas"}) {
            JButton chip = chipButton(sample);
            chip.addActionListener(e -> runSearch(sample));
            chips.add(chip);
        }
        chips.setAlignmentX(Component.CENTER_ALIGNMENT);
        center.add(chips);
        center.add(Box.createVerticalStrut(55));

        JPanel featureRow = new JPanel(new GridLayout(1, 3, 14, 0));
        featureRow.setOpaque(false);
        featureRow.add(featureCard("◉", "Live results", "Search the web in real time"));
        featureRow.add(featureCard("⚡", "Quick & simple", "One search, useful answers"));
        featureRow.add(featureCard("⌘", "Java powered", "Built with Java Swing"));
        featureRow.setMaximumSize(new Dimension(760, 92));
        featureRow.setAlignmentX(Component.CENTER_ALIGNMENT);
        center.add(featureRow);
        root.add(center, BorderLayout.CENTER);

        JLabel footer = new JLabel("An educational project · Not affiliated with Google");
        footer.setForeground(new Color(120, 133, 160));
        footer.setFont(SMALL);
        footer.setHorizontalAlignment(SwingConstants.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        frame.setContentPane(root);
        frame.setVisible(true);
        searchBox.requestFocusInWindow();
        search.addActionListener(e -> runSearch(searchBox.getText().trim()));
        searchBox.addActionListener(e -> runSearch(searchBox.getText().trim()));
    }

    private void showResultsPage() {
        resultsMode = true;
        frame.getContentPane().removeAll();
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);

        JPanel top = new JPanel(new BorderLayout(22, 0));
        top.setBackground(PANEL);
        top.setBorder(new EmptyBorder(17, 28, 17, 28));
        JLabel brand = brandLabel(23);
        brand.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        brand.setToolTipText("Back to home");
        brand.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) { showHome(); }
        });
        top.add(brand, BorderLayout.WEST);

        JPanel searchWrap = new RoundedPanel(PANEL_LIGHT, 18);
        searchWrap.setLayout(new BorderLayout(10, 0));
        searchWrap.setBorder(new EmptyBorder(6, 15, 6, 7));
        searchBox = createSearchField("Search the web...");
        searchWrap.add(searchBox, BorderLayout.CENTER);
        JButton search = accentButton("Search ↗");
        searchWrap.add(search, BorderLayout.EAST);
        top.add(searchWrap, BorderLayout.CENTER);
        JLabel badge = new JLabel("LIVE");
        badge.setFont(new Font("SansSerif", Font.BOLD, 10));
        badge.setForeground(new Color(134, 239, 172));
        top.add(badge, BorderLayout.EAST);
        root.add(top, BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout());
        body.setBackground(BG);
        results = new JPanel();
        results.setLayout(new BoxLayout(results, BoxLayout.Y_AXIS));
        results.setBackground(BG);
        results.setBorder(new EmptyBorder(24, 0, 35, 0));
        JPanel resultHolder = new JPanel(new BorderLayout());
        resultHolder.setBackground(BG);
        resultHolder.setBorder(new EmptyBorder(0, 55, 0, 55));
        resultHolder.add(results, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(resultHolder);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(BG);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        body.add(scroll, BorderLayout.CENTER);
        status = new JLabel("Ready when you are — search the live web");
        status.setForeground(MUTED);
        status.setFont(SMALL);
        status.setBorder(new EmptyBorder(12, 56, 14, 10));
        status.setOpaque(true);
        status.setBackground(PANEL);
        body.add(status, BorderLayout.SOUTH);
        root.add(body, BorderLayout.CENTER);
        frame.setContentPane(root);
        frame.revalidate();
        frame.repaint();
        search.addActionListener(e -> runSearch(searchBox.getText().trim()));
        searchBox.addActionListener(e -> runSearch(searchBox.getText().trim()));
    }

    private void runSearch(String query) {
        if (query == null || query.isBlank()) {
            if (searchBox != null) searchBox.requestFocusInWindow();
            return;
        }
        if (!resultsMode) showResultsPage();
        searchBox.setText(query);
        results.removeAll();
        JPanel loading = new RoundedPanel(PANEL, 18);
        loading.setLayout(new BorderLayout(14, 0));
        loading.setBorder(new EmptyBorder(20, 22, 20, 22));
        JProgressBar progress = new JProgressBar();
        progress.setIndeterminate(true);
        progress.setBorderPainted(false);
        progress.setPreferredSize(new Dimension(80, 5));
        progress.setForeground(ACCENT);
        progress.setBackground(PANEL_LIGHT);
        loading.add(progress, BorderLayout.WEST);
        JLabel loadingText = new JLabel("Searching the web for “" + query + "”…");
        loadingText.setForeground(TEXT);
        loadingText.setFont(BODY);
        loading.add(loadingText, BorderLayout.CENTER);
        loading.setAlignmentX(Component.LEFT_ALIGNMENT);
        results.add(loading);
        status.setText("Connecting to live search service…");
        results.revalidate();
        results.repaint();

        new SwingWorker<List<WebResult>, Void>() {
            protected List<WebResult> doInBackground() throws Exception { return web.search(query, 10); }
            protected void done() {
                try { renderResults(query, get()); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); showError("Search was interrupted."); }
                catch (ExecutionException e) {
                    Throwable cause = e.getCause();
                    showError(cause == null ? "Something went wrong. Please try again." : cause.getMessage());
                }
            }
        }.execute();
    }

    private void renderResults(String query, List<WebResult> found) {
        results.removeAll();
        JLabel heading = new JLabel("Search results");
        heading.setFont(new Font("SansSerif", Font.BOLD, 23));
        heading.setForeground(TEXT);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);
        results.add(heading);
        results.add(Box.createVerticalStrut(6));
        JLabel queryLabel = new JLabel("Showing matches for  “" + query + "”");
        queryLabel.setFont(BODY);
        queryLabel.setForeground(MUTED);
        queryLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        results.add(queryLabel);
        results.add(Box.createVerticalStrut(20));
        status.setText(found.size() + " results found  ·  Query: “" + query + "”");
        if (found.isEmpty()) {
            JPanel empty = new RoundedPanel(PANEL, 18);
            empty.setLayout(new BoxLayout(empty, BoxLayout.Y_AXIS));
            empty.setBorder(new EmptyBorder(25, 25, 25, 25));
            JLabel title = new JLabel("No results this time");
            title.setForeground(TEXT); title.setFont(TITLE);
            JLabel tip = new JLabel("Try different keywords, or check your internet connection.");
            tip.setForeground(MUTED); tip.setFont(BODY);
            empty.add(title); empty.add(Box.createVerticalStrut(8)); empty.add(tip);
            empty.setAlignmentX(Component.LEFT_ALIGNMENT); results.add(empty);
        } else {
            int rank = 1;
            for (WebResult r : found) {
                JPanel card = createResult(rank++, r);
                results.add(card);
                results.add(Box.createVerticalStrut(13));
                suggestions.insert(r.getTitle());
            }
        }
        results.revalidate(); results.repaint();
    }

    private JPanel createResult(int rank, WebResult r) {
        JPanel card = new RoundedPanel(PANEL, 18);
        card.setLayout(new BorderLayout(14, 0));
        card.setBorder(new EmptyBorder(17, 19, 17, 19));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 180));

        JLabel number = new JLabel(String.format("%02d", rank));
        number.setFont(new Font("SansSerif", Font.BOLD, 12));
        number.setForeground(new Color(196, 181, 253));
        number.setVerticalAlignment(SwingConstants.TOP);
        card.add(number, BorderLayout.WEST);

        JPanel details = new JPanel();
        details.setOpaque(false);
        details.setLayout(new BoxLayout(details, BoxLayout.Y_AXIS));
        JLabel domain = new JLabel(displayDomain(r.getUrl()));
        domain.setFont(SMALL); domain.setForeground(URL);
        domain.setAlignmentX(Component.LEFT_ALIGNMENT);
        details.add(domain);
        details.add(Box.createVerticalStrut(5));

        JLabel title = new JLabel("<html><u>" + esc(r.getTitle()) + "</u></html>");
        title.setFont(TITLE); title.setForeground(new Color(167, 194, 255));
        title.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        title.setToolTipText("Open this website in your browser");
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        title.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) { open(r.getUrl()); }
            @Override public void mouseEntered(java.awt.event.MouseEvent e) { title.setForeground(ACCENT_2); }
            @Override public void mouseExited(java.awt.event.MouseEvent e) { title.setForeground(new Color(167, 194, 255)); }
        });
        details.add(title);
        details.add(Box.createVerticalStrut(8));
        JTextArea snippet = new JTextArea(r.getSnippet().isBlank() ? "No description available for this result." : r.getSnippet());
        snippet.setFont(BODY); snippet.setForeground(new Color(190, 199, 218));
        snippet.setLineWrap(true); snippet.setWrapStyleWord(true); snippet.setEditable(false);
        snippet.setOpaque(false); snippet.setFocusable(false); snippet.setBorder(null);
        snippet.setAlignmentX(Component.LEFT_ALIGNMENT);
        details.add(snippet);
        details.add(Box.createVerticalStrut(10));
        JLabel score = new JLabel(String.format("RELEVANCE  %.0f%%", r.getScore() * 100));
        score.setFont(new Font("SansSerif", Font.BOLD, 10)); score.setForeground(MUTED);
        score.setAlignmentX(Component.LEFT_ALIGNMENT);
        details.add(score);
        card.add(details, BorderLayout.CENTER);

        JPopupMenu menu = new JPopupMenu();
        JMenuItem copy = new JMenuItem("Copy URL");
        copy.addActionListener(e -> Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(r.getUrl()), null));
        menu.add(copy);
        title.setComponentPopupMenu(menu); domain.setComponentPopupMenu(menu); card.setComponentPopupMenu(menu);
        card.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
        return card;
    }

    private void showError(String message) {
        results.removeAll();
        JPanel error = new RoundedPanel(new Color(60, 30, 47), 18);
        error.setLayout(new BoxLayout(error, BoxLayout.Y_AXIS));
        error.setBorder(new EmptyBorder(22, 24, 22, 24));
        JLabel title = new JLabel("Couldn't load search results");
        title.setFont(TITLE); title.setForeground(new Color(254, 205, 211));
        JLabel detail = new JLabel("<html>" + esc(message == null ? "Unknown error" : message) + "<br/>Please try again in a moment.</html>");
        detail.setFont(BODY); detail.setForeground(new Color(238, 190, 200));
        JButton retry = chipButton("Try again ↻");
        retry.setAlignmentX(Component.LEFT_ALIGNMENT);
        retry.addActionListener(e -> runSearch(searchBox.getText().trim()));
        error.add(title); error.add(Box.createVerticalStrut(9)); error.add(detail);
        error.add(Box.createVerticalStrut(15)); error.add(retry);
        error.setAlignmentX(Component.LEFT_ALIGNMENT);
        results.add(error);
        status.setText("Search failed · Check your connection and retry");
        results.revalidate(); results.repaint();
    }

    private JPanel featureCard(String icon, String title, String description) {
        JPanel p = new RoundedPanel(new Color(25, 33, 55, 220), 16);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(new EmptyBorder(14, 16, 14, 16));
        JLabel iconLabel = new JLabel(icon); iconLabel.setFont(new Font("SansSerif", Font.BOLD, 17)); iconLabel.setForeground(new Color(196, 181, 253));
        JLabel titleLabel = new JLabel(title); titleLabel.setFont(new Font("SansSerif", Font.BOLD, 12)); titleLabel.setForeground(TEXT);
        JLabel descLabel = new JLabel(description); descLabel.setFont(new Font("SansSerif", Font.PLAIN, 11)); descLabel.setForeground(MUTED);
        p.add(iconLabel); p.add(Box.createVerticalStrut(4)); p.add(titleLabel); p.add(Box.createVerticalStrut(3)); p.add(descLabel);
        return p;
    }

    private JLabel brandLabel(int size) {
        JLabel brand = new JLabel("✦  Mini Google");
        brand.setFont(new Font("SansSerif", Font.BOLD, size));
        brand.setForeground(TEXT);
        return brand;
    }

    private JTextField createSearchField(String placeholder) {
        JTextField field = new JTextField();
        field.setFont(new Font("SansSerif", Font.PLAIN, 15));
        field.setForeground(TEXT);
        field.setCaretColor(TEXT);
        field.setOpaque(false);
        field.setBorder(null);
        field.setToolTipText(placeholder);
        field.setPreferredSize(new Dimension(280, 38));
        return field;
    }

    private JButton accentButton(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("SansSerif", Font.BOLD, 13));
        b.setForeground(Color.WHITE);
        b.setBackground(ACCENT);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(new EmptyBorder(11, 18, 11, 18));
        return b;
    }

    private JButton chipButton(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("SansSerif", Font.PLAIN, 12));
        b.setForeground(new Color(216, 222, 241));
        b.setBackground(PANEL_LIGHT);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(new EmptyBorder(9, 13, 9, 13));
        return b;
    }

    private static String displayDomain(String url) {
        try { return URI.create(url).getHost() == null ? url : URI.create(url).getHost().replaceFirst("^www\\.", ""); }
        catch (Exception e) { return url; }
    }

    private static void open(String url) {
        try { Desktop.getDesktop().browse(URI.create(url)); }
        catch (Exception e) { JOptionPane.showMessageDialog(null, "Could not open URL:\n" + url, "Open Website", JOptionPane.ERROR_MESSAGE); }
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private static class RoundedPanel extends JPanel {
        private final Color color;
        private final int radius;
        RoundedPanel(Color color, int radius) { this.color = color; this.radius = radius; setOpaque(false); }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color); g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.dispose(); super.paintComponent(g);
        }
    }

    private static class GradientPanel extends JPanel {
        GradientPanel() { setOpaque(false); }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g2.setPaint(new GradientPaint(0, 0, new Color(18, 24, 46), getWidth(), getHeight(), new Color(34, 24, 70)));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setColor(new Color(139, 92, 246, 22));
            g2.fillOval(getWidth() - 370, 60, 460, 460);
            g2.setColor(new Color(56, 189, 248, 15));
            g2.fillOval(-180, getHeight() - 300, 420, 420);
            g2.dispose(); super.paintComponent(g);
        }
    }
}
