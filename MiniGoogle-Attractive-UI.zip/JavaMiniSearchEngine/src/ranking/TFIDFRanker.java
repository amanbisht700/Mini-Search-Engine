package ranking;
import indexing.Indexer; import model.Document; import java.util.*;
public class TFIDFRanker implements Ranker { private final Map<Integer,Document> docs; public TFIDFRanker(Map<Integer,Document> docs){this.docs=docs;}
 public double score(Document d,String query){List<String> q=Indexer.tokenize(query),w=Indexer.tokenize(d.getContent()+" "+d.getTitle());if(q.isEmpty())return 0;Map<String,Integer> tf=new HashMap<>(),qt=new HashMap<>();w.forEach(x->tf.merge(x,1,Integer::sum));q.forEach(x->qt.merge(x,1,Integer::sum));double dot=0,dn=0,qn=0;
  for(String term:new HashSet<>(q)){double df=docs.values().stream().filter(x->Indexer.tokenize(x.getContent()+" "+x.getTitle()).contains(term)).count();double idf=Math.log((docs.size()+1.0)/(df+1.0))+1.0;double dw=tf.getOrDefault(term,0)*idf,qw=qt.getOrDefault(term,0)*idf;dot+=dw*qw;dn+=dw*dw;qn+=qw*qw;}
  double cosine=(dn==0||qn==0)?0:dot/(Math.sqrt(dn)*Math.sqrt(qn)); long title=q.stream().filter(x->d.getTitle().toLowerCase(Locale.ROOT).contains(x)).count();return cosine+title*.05;
 }
}
