package ranking; import model.Document; public interface Ranker{double score(Document document,String query);}
