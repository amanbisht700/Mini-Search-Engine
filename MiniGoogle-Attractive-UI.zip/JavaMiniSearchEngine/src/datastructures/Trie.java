package datastructures;
import java.util.*;
public class Trie { private static class Node{Map<Character,Node> children=new HashMap<>();boolean word;} private final Node root=new Node();
 public void insert(String s){Node n=root;for(char c:s.toLowerCase().toCharArray())n=n.children.computeIfAbsent(c,k->new Node());n.word=true;}
 public List<String> autocomplete(String p,int limit){List<String> r=new ArrayList<>();Node n=root;for(char c:p.toLowerCase().toCharArray()){n=n.children.get(c);if(n==null)return r;}collect(n,new StringBuilder(p.toLowerCase()),r,limit);return r;}
 private void collect(Node n,StringBuilder s,List<String> r,int limit){if(r.size()>=limit)return;if(n.word)r.add(s.toString());for(var e:new TreeMap<>(n.children).entrySet()){s.append(e.getKey());collect(e.getValue(),s,r,limit);s.deleteCharAt(s.length()-1);}}
}
