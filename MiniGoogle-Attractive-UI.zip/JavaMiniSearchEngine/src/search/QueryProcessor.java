package search; import indexing.Indexer; import java.util.*;
public class QueryProcessor{private static final Set<String> STOP=Set.of("the","is","a","an","and","or","of","to","in","for"); public List<String> process(String q){return Indexer.tokenize(q).stream().filter(x->!STOP.contains(x)).distinct().toList();}}
