package search;
import indexing.*; import model.*; import ranking.Ranker; import java.util.*;
public class SearchEngine {private final Indexer indexer;private final QueryProcessor processor=new QueryProcessor();private final Ranker ranker;public SearchEngine(Indexer i,Ranker r){indexer=i;ranker=r;}
 public List<SearchResult> search(String q,int limit){List<String> terms=processor.process(q);if(terms.isEmpty())return List.of();Set<Integer> ids=new HashSet<>();for(String t:terms)ids.addAll(indexer.getIndex().get(t));PriorityQueue<SearchResult> pq=new PriorityQueue<>(Comparator.comparingDouble(SearchResult::getScore));for(int id:ids){Document d=indexer.getDocuments().get(id);double s=ranker.score(d,q);if(s<=0)continue;pq.offer(new SearchResult(d,s));if(pq.size()>limit)pq.poll();}List<SearchResult> out=new ArrayList<>(pq);out.sort(Comparator.comparingDouble(SearchResult::getScore).reversed());return out;}
}
