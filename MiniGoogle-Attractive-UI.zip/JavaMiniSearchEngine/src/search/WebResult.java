package search;

/** Represents one result discovered from the live web. */
public class WebResult {
    private final String title;
    private final String url;
    private final String snippet;
    private final double score;

    public WebResult(String title, String url, String snippet, double score) {
        this.title = title;
        this.url = url;
        this.snippet = snippet;
        this.score = score;
    }

    public String getTitle() { return title; }
    public String getUrl() { return url; }
    public String getSnippet() { return snippet; }
    public double getScore() { return score; }
}
