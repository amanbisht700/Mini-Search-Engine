package search;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.URLDecoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Live web-search client for the educational Mini Google project.
 * It queries DuckDuckGo's HTML search endpoint and converts the response
 * into simple Java objects. No API key is required.
 */
public class WebSearchClient {
    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    public List<WebResult> search(String query, int limit) throws IOException, InterruptedException {
        if (query == null || query.isBlank()) return List.of();

        String encoded = URLEncoder.encode(query.trim(), StandardCharsets.UTF_8);
        URI uri = URI.create("https://html.duckduckgo.com/html/?q=" + encoded);
        HttpRequest request = HttpRequest.newBuilder(uri)
                .timeout(Duration.ofSeconds(15))
                .header("User-Agent", "Mozilla/5.0 MiniGoogleEducationalProject/1.0")
                .header("Accept-Language", "en-US,en;q=0.9")
                .GET().build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() >= 400) {
            throw new IOException("Search service returned HTTP " + response.statusCode());
        }
        return parse(response.body(), limit, query);
    }

    private List<WebResult> parse(String html, int limit, String query) {
        List<WebResult> results = new ArrayList<>();
        Pattern resultPattern = Pattern.compile(
                "(?is)<div[^>]*class=\\\"result[^>]*>(.*?)</div>\\s*</div>");
        Matcher blocks = resultPattern.matcher(html);

        while (blocks.find() && results.size() < limit) {
            String block = blocks.group(1);
            Matcher link = Pattern.compile("(?is)<a[^>]*class=\\\"result__a\\\"[^>]*href=\\\"([^\\\"]+)\\\"[^>]*>(.*?)</a>").matcher(block);
            Matcher snippet = Pattern.compile("(?is)<a[^>]*class=\\\"result__snippet[^>]*>(.*?)</a>|<div[^>]*class=\\\"result__snippet[^>]*>(.*?)</div>").matcher(block);
            if (!link.find()) continue;

            String url = decodeRedirect(link.group(1));
            String title = clean(link.group(2));
            String text = snippet.find() ? clean(snippet.group(1) != null ? snippet.group(1) : snippet.group(2)) : "";
            if (url.isBlank() || title.isBlank()) continue;

            double score = relevance(title + " " + text, query);
            results.add(new WebResult(title, url, text, score));
        }

        // Fallback parser for small changes in the search page markup.
        if (results.isEmpty()) {
            Pattern p = Pattern.compile("(?is)<a[^>]*class=\\\"result__a\\\"[^>]*href=\\\"([^\\\"]+)\\\"[^>]*>(.*?)</a>");
            Matcher m = p.matcher(html);
            while (m.find() && results.size() < limit) {
                String url = decodeRedirect(m.group(1));
                String title = clean(m.group(2));
                if (!url.isBlank() && !title.isBlank()) {
                    results.add(new WebResult(title, url, "Web result", relevance(title, query)));
                }
            }
        }
        return results;
    }

    private static double relevance(String text, String query) {
        List<String> q = tokens(query);
        String t = text.toLowerCase(Locale.ROOT);
        double score = 0;
        for (String term : q) {
            if (t.contains(term)) score += 1.0;
        }
        return q.isEmpty() ? 0 : score / q.size();
    }

    private static List<String> tokens(String s) {
        return Arrays.stream(s.toLowerCase(Locale.ROOT).split("[^\\p{L}\\p{Nd}]+"))
                .filter(x -> x.length() > 1).toList();
    }

    private static String decodeRedirect(String value) {
        try {
            if (value.contains("uddg=")) {
                String encoded = value.substring(value.indexOf("uddg=") + 5);
                int amp = encoded.indexOf('&');
                if (amp >= 0) encoded = encoded.substring(0, amp);
                return URLDecoder.decode(encoded, StandardCharsets.UTF_8);
            }
            return value.startsWith("//") ? "https:" + value : value;
        } catch (Exception e) {
            return value;
        }
    }

    private static String clean(String html) {
        return html.replaceAll("(?is)<script.*?</script>", " ")
                .replaceAll("(?is)<style.*?</style>", " ")
                .replaceAll("(?is)<[^>]+>", " ")
                .replace("&amp;", "&").replace("&quot;", "\"")
                .replace("&#x27;", "'").replace("&#39;", "'")
                .replace("&lt;", "<").replace("&gt;", ">")
                .replaceAll("\\s+", " ").trim();
    }
}
