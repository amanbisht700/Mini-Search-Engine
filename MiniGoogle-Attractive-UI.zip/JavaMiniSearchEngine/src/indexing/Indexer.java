package indexing;

import model.Document;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public class Indexer {
    private final InvertedIndex index = new InvertedIndex();
    private final Map<Integer, Document> documents = new ConcurrentHashMap<>();

    public void indexDirectory(Path dir) throws IOException {
        Files.createDirectories(dir);
        List<Path> paths;
        try (var s = Files.list(dir)) {
            paths = s.filter(Files::isRegularFile)
                    .filter(p -> p.toString().toLowerCase().endsWith(".txt"))
                    .toList();
        }

        ExecutorService ex = Executors.newFixedThreadPool(Math.max(2, Runtime.getRuntime().availableProcessors()));
        List<Future<?>> jobs = new ArrayList<>();
        int id = 1;
        for (Path p : paths) {
            final int docId = id++;
            jobs.add(ex.submit(() -> indexFile(p, docId)));
        }
        for (Future<?> f : jobs) {
            try {
                f.get();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IOException(e);
            } catch (ExecutionException e) {
                throw new IOException(e.getCause());
            }
        }
        ex.shutdown();
    }

    private void indexFile(Path p, int id) {
        try {
            String c = Files.readString(p);
            String title = extractMetadata(c, "TITLE:", p.getFileName().toString());
            String url = extractMetadata(c, "URL:", p.toUri().toString());
            String body = c;
            int separator = c.indexOf("\n\n");
            if (separator >= 0) body = c.substring(separator + 2);

            Document d = new Document(id, title, body, p.toString(), url);
            documents.put(id, d);
            tokenize(title + " " + body).forEach(t -> index.add(t, id));
        } catch (IOException e) {
            System.err.println("Could not read " + p);
        }
    }

    private static String extractMetadata(String text, String prefix, String fallback) {
        for (String line : text.split("\\R", 8)) {
            if (line.startsWith(prefix)) {
                String value = line.substring(prefix.length()).trim();
                if (!value.isEmpty()) return value;
            }
        }
        return fallback;
    }

    public static List<String> tokenize(String text) {
        String cleaned = text.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{Nd}]+", " ").trim();
        if (cleaned.isEmpty()) return List.of();
        return Arrays.stream(cleaned.split("\\s+"))
                .filter(s -> s.length() > 1)
                .toList();
    }

    public InvertedIndex getIndex() { return index; }
    public Map<Integer, Document> getDocuments() { return documents; }
}
