package indexing;
import java.io.*; import java.util.*; import java.util.concurrent.ConcurrentHashMap;
public class InvertedIndex implements Serializable {
 private static final long serialVersionUID=1L; private final Map<String,Set<Integer>> index=new ConcurrentHashMap<>();
 public void add(String term,int id){index.computeIfAbsent(term,k->ConcurrentHashMap.newKeySet()).add(id);}
 public Set<Integer> get(String term){return index.getOrDefault(term,Collections.emptySet());} public Set<String> terms(){return index.keySet();}
 public void save(File f)throws IOException{try(ObjectOutputStream o=new ObjectOutputStream(new FileOutputStream(f))){o.writeObject(this);}}
 public static InvertedIndex load(File f)throws IOException,ClassNotFoundException{try(ObjectInputStream i=new ObjectInputStream(new FileInputStream(f))){return (InvertedIndex)i.readObject();}}
}
